<?php

    // configuration
    require("../includes/config.php"); 

    $positions = [];
    
    $rows = CS50::query("SELECT buy_sell, date_time, symbol, shares, price FROM history WHERE user_id = ?", $_SESSION["id"]);
    foreach ($rows as $row)
    {
        $positions[] = 
                [
                    "buy_sell" => $row["buy_sell"],
                    "date_time" => $row["date_time"],
                    "symbol" => $row["symbol"],
                    "shares" => $row["shares"],
                    "price" => $row["price"],
                ];
    }
    render("history_view.php", ["title" => "Portfolio", "positions" => $positions]);

?>
