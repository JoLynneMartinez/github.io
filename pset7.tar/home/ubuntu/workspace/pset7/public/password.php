<?php

    // configuration
    require("../includes/config.php");
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("../views/password_form.php", ["title" => "Password Reset"]);
    }
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        //Post the user inputs
        $_POST["password1"];
        $password1 = $_POST["password1"];
        $_POST["password2"];
        $password2 = $_POST["password2"];
        //if the user does not enter a first password, apologize
        if (empty($_POST["password1"]))
        {
            apologize("You must provide a password.");
        }
        //if the user does not re-enter the password, apologize
        else if (empty($_POST["password2"]))
        {
            apologize("You must confirm your password.");
        }
        //if the passwords do not match, apologize
        else if ($_POST["password1"] != $_POST["password2"])
        {
            apologize("Your password and confirmation must match. Try again.");
        }
        else
        {
            //update the SQL users table
            $reset = CS50::query("UPDATE users SET hash = ? WHERE id = ?", password_hash($_POST["password1"], PASSWORD_DEFAULT), $_SESSION["id"]);    
            if($reset = true)
            {
                redirect("index.php");
            }
        }   
    }
    //render password reset form
    render("password_form.php", ["title" => "Reset Password"]);
?>