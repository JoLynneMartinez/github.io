<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect, refresh the register form)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("register_form.php", ["title" => "Register"]);
    }
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        //Post the user inputs
        $_POST["username"];
        $username = $_POST["username"];
        $_POST["email"];
        $email = $_POST["email"];
        $_POST["password1"];
        $password1 = $_POST["password1"];
        $_POST["password2"];
        $password2 = $_POST["password1"];
        // If the user does not enter a username, apologize
        if (empty($_POST["username"]))
        {
            apologize("You must provide your username.");
        }
        // If the user does not enter an email address, apologize
        if (empty($_POST["email"]))
        {
            apologize("You must provide an email address.");
        }
        //if the user does not enter a first password, apologize
        else if (empty($_POST["password1"]))
        {
            apologize("You must provide a password.");
        }
        //if the user does not re-enter the password, apologize
        else if (empty($_POST["password2"]))
        {
            apologize("You must confirm your password.");
        }
        //if the passwords do not match, apologize
        else if ($_POST["password1"] != $_POST["password2"])
        {
            apologize("Your password and confirmation must match. Try again.");
        }
        else
        {
            //register the new user in the SQL users table
            $user_name = CS50::query("INSERT IGNORE INTO users (username, email, hash, cash) VALUES(?, ?, ?, 10000.0000)", $username, $email, password_hash($_POST["password1"], PASSWORD_DEFAULT));
            // if username already exists, apologize
            if ($user_name == false)
            {
                apologize("That user name is already taken. Please try again.");
            }
            //log the new user in to the site
            else if (count($user_name) == true)
            {
                // query database for user
                $rows = CS50::query("SELECT * FROM users WHERE username = ?", $username);
                // if we find user, check password
                if (count($rows) == 1)
                {
                    // first (and only) row
                    $row = $rows[0];
                    // compare hash of user's input against hash that's in database
                    if (password_verify($password1, $row["hash"]))
                    {
                        //find out which id was assigned to that user
                        $rows = CS50::query("SELECT LAST_INSERT_ID() AS id");
                        $id = $rows[0]["id"];
                        // remember that user's now logged in by storing user's ID in session
                        $_SESSION["id"] = $id;
                        // redirect to portfolio
                        redirect("index.php");
                    }
                }

            }
        }
    }
?>