<?php

    // configuration
    require("../includes/config.php"); 

    $positions = [];
    
    $rows = CS50::query("SELECT shares, symbol FROM portfolios WHERE user_id = ?", $_SESSION["id"]);
    foreach ($rows as $row)
    {
        $stock = lookup($row["symbol"]);
        
        if ($stock !== false)
        {
            $positions[] = 
                [
                    "symbol" => $row["symbol"],
                    "name" => $stock["name"],
                    "shares" => number_format($row["shares"]),
                    "price" => number_format($stock["price"], 2),
                    "row_total" => number_format($row["shares"] * $stock["price"], 2),
                ];
        }
    }
    
    $current_cash = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
render("portfolio.php", ["title" => "Portfolio", "positions" => $positions, "cash" => number_format($current_cash[0]["cash"], 2)]);

?>
