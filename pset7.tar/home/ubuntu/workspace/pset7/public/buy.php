<?php

    // configuration
    require("../includes/config.php");
    $cash = [];
    $symbol_search = [];
    
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // make sure user enters required fields
        if (empty($_POST["symbol"]))
        {
            apologize("You must enter a three- or four-letter stock symbol.");
        }
        if (empty($_POST["shares"]))
        {
            apologize("You must enter the number of shares you would like to purchase.");
        }
        else
        {
            if (!empty($_POST["symbol"]))
            {
                //get user input (number of shares)
                $_POST["shares"];
                $shares = $_POST["shares"];
                if (ctype_digit($shares) == false)
                {
                    apologize("You may only purchase whole shares of stock. No fractional purchases, please.");
                }
                //get the user input (stock symbol)
                $_POST["symbol"];
                $symbol = $_POST["symbol"];
                //make sure stock symbol is in all uppercase letters
                $symbol = strtoupper($symbol);
                //what is the current price per share of stock the user wants to buy?
                $stock = lookup($symbol);
                    
                if ($stock !== false)
                {
                    $price[] = ["price" => $stock["price"]];
                    $price = $price[0]["price"];
                }
                //what is the cost of purchasing the number of shares the user wants to buy?
                $total_cost = number_format($shares) * number_format($price, 2);
                //can the user afford this purchase?
                $cash = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
                $cash = $cash[0]["cash"];
                if($cash < $total_cost)
                {
                    apologize("You can't afford that.");
                }
                elseif($cash > $total_cost)
                {
                    //Does the stock the user wants to buy already exist in the portfolio?
                    $symbol_search = CS50::query("SELECT symbol FROM portfolios WHERE symbol = ? AND user_id = ?", $symbol, $_SESSION["id"]);
                    $symbol_search = $symbol_search[0]["symbol"];
                    $symbol_search = strtoupper($symbol_search);
                    //Does the user already own shares of this stock?
                    if($symbol_search == $symbol)
                    {
                        //enter stock symbol into table on same row as pre-existing stock symbol
                        CS50::query("UPDATE portfolios SET shares = shares + ? WHERE user_id = ? AND symbol = ?", $shares, $_SESSION["id"], $symbol);
                        //deduct stock purchase price from account
                        $buy1 = CS50::query("UPDATE users SET cash = cash - ? WHERE id = ?", $total_cost, $_SESSION["id"]);
                        //update history
                        $history = CS50::query("INSERT INTO history (user_id, buy_sell, date_time, symbol, shares, price) VALUES (?, ?, (select now()), ?, ?, ?)", $_SESSION["id"], "BUY", $symbol, $shares, $price);
                        if($buy1 = true)
                        {
                            redirect("index.php");
                        }
                    }
                    //Do this if the user does not already own shares of this stock.
                    elseif($symbol_search != $symbol)
                    {
                        //enter stock symbol into table on new row of table
                        CS50::query("INSERT INTO portfolios (user_id, symbol, shares) VALUES(?, ?, ?)", $_SESSION["id"], $symbol, $shares);
                        //deduct stock purchase price from account
                        $buy2 = CS50::query("UPDATE users SET cash = cash - ? WHERE id = ?", $total_cost, $_SESSION["id"]);
                        //update history
                        $history = CS50::query("INSERT INTO history (user_id, buy_sell, date_time, symbol, shares, price) VALUES (?, ?, (select now()), ?, ?, ?)", $_SESSION["id"], "BUY", $symbol, $shares, $price);
                        if($buy2 = true)
                        {
                            redirect("index.php");
                        }
                    }
                }
            }
        }
    }
render("../views/buy_form.php", ["title" => "Buy"]);
?>