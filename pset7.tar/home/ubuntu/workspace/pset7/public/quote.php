<?php

    // configuration
    require("../includes/config.php");
    
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("../views/quote_form.php", ["title" => "Quote"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_POST["symbol"];
        
        if (empty($_POST["symbol"]))
        {
            apologize("You must enter a stock symbol.");
        }
        else
        {
            $stock = lookup($_POST["symbol"]);
            
            if ($stock == false)
            {
                apologize("You did not enter a valid stock symbol.");
            }
            else
            {
                render("../views/lookup.php", ["title" => "Quote", "stock" => lookup($_POST["symbol"])]);
            }
        }
    }
?>