<?php

    // configuration
    require("../includes/config.php");
    
    $positions = [];
    $row = [];
    $shares = [];
    $price = [];
    $cash = [];
    
     //look up the stocks in the user's portfolio and list them in the sell_form
    $rows = CS50::query("SELECT user_id, symbol FROM portfolios WHERE user_id = ?", $_SESSION["id"]);
    foreach ($rows as $row)
    {
        $stock = lookup($row["symbol"]);
                
        if ($stock !== false)
        {
            $positions[] = 
                [
                    "symbol" => $row["symbol"]
                ];
        }
    }
    
    //if a stock is not selected, apologize
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        ///if no symbol is selected, apologize
        if (empty($_POST["symbol"]))
        {
            apologize("You must select a stock to sell.");
        }
        //if no number of shares is entered, apologize
        elseif (empty($_POST["shares"]))
        {
            apologize("You must enter a number of shares to sell.");
        }
        //if a symbol and number of shares are selected
        elseif(!empty($_POST["shares"]) && !empty($_POST["symbol"]))
        {
            //Post the symbol the user has selected
            $_POST["symbol"];
            $symbol = $_POST["symbol"];
            
            //Post the number of shares the user has selected
            $_POST["shares"];
            $shares1 = $_POST["shares"];
            //Find the number of shares of that stock in the user's portfolio
            $shares = CS50::query("SELECT shares FROM portfolios WHERE symbol = ? AND user_id = ?", $_POST["symbol"], $_SESSION["id"]);
            $shares2 = $shares[0]["shares"];
            if (ctype_digit($shares1) == false)
            {
                apologize("You may only sell whole shares of stock. No fractional sales, please.");
            }
            elseif(ctype_digit($shares1) == true)
            {
                //Find out how much the current valuation of a share of that stock
                $stock = lookup($row["symbol"]);
                if ($stock !== false)
                {
                    $price[] = ["price" => $stock["price"]];
                    $price = $price[0]["price"];
                }
                //Multiply the number of shares of that stock by the current price per share
                $cash = $shares1 * $price;
        
                //Deposit those funds in the user's account        
                $deposit = cs50::query("UPDATE users set cash = cash + ? WHERE id = ?", $cash, $_SESSION["id"]);
                
                //if number of shares the user wants to sell exceeds the number of shares in the portfolio, apologize
                if($shares1 > $shares2)
                {
                    apologize("You do not have that many shares to sell.");
                }
                //if the user is selling all shares of that stock
                else if($shares1 == $shares2)
                {
                    //Delete the stock that has been sold from the user's portfolio
                    $sell = CS50::query("DELETE FROM portfolios WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
                    //update history
                    $history = CS50::query("INSERT INTO history (user_id, buy_sell, date_time, symbol, shares, price) VALUES (?, ?, (select now()), ?, ?, ?)", $_SESSION["id"], "SELL", $symbol, $shares2, $price);
                    //redirect user to the index page
                    if($sell = true)
                    {
                        redirect("index.php");
                    }
                }
                //if the user is not selling all shares
                else
                {
                    //Update the number of share in the user's portfolio
                    CS50::query("UPDATE portfolios SET shares = shares - ? WHERE user_id = ? AND symbol = ?", $shares1, $_SESSION["id"], $symbol);
                    //update history
                    $history = CS50::query("INSERT INTO history (user_id, buy_sell, date_time, symbol, shares, price) VALUES (?, ?, (select now()), ?, ?, ?)", $_SESSION["id"], "SELL", $symbol, $shares1, $price);
                    //redirect user to the index page
                    if($sell = true)
                    {
                        redirect("index.php");
                    }
                }
            }
        }
    }
    //render the sell form
    render("../views/sell_form.php", ["title" => "Sell", "positions" => $positions]);
?>