<?php

    // configuration
    require("../includes/config.php");
    //if ($_SERVER["REQUEST_METHOD"] == "GET")
    //{
        // else render form
    //    render("../views/forgot_form.php", ["title" => "Forgot"]);
    //}
    // else if user reached page via POST (as by submitting a form via POST)
    //else if ($_SERVER["REQUEST_METHOD"] == "POST")
    //{
        //Post the user input
    //    $_POST["email"];
    //    $email1 = $_POST["email"];
        //find the password associated with the e-mail address entered by the user
    //    $rows = CS50::query("SELECT hash FROM users WHERE email = ?", $email1);
        //if the user does not enter an e-mail address, apologize
    //    if (empty($email1))
    //    {
    //        apologize("You must provide an e-mail address.");
    //    }
        //does the email address the user entered match one in the users table?
    //    else if (!empty($email1))
    //    {
            // first (and only) row
    //        $email2 = $rows[0];
            // compare hash of user's input against hash that's in database
    //        if (password_verify($email1, $email2["hash"]))
    //        {
                //provide a temporary password for the account associated with that e-mail address
    //            $temp_password = CS50::query("UPDATE users SET password = 12345 WHERE email = ?", $email1);
                //send password in an e-mail to the user
    //            if($temp_password == true)
    //            {
                    //send e-mail with temporary password to user
                    // The message
    //                $message = "Forgot your password, huh?\r\nYour new temporary password is 12345.\r\nBe sure to reset your password as soon as you log in again.\r\n(Do not respond to this an automated message KCA's Fantasy Stock Portfolio Site.\r\nIf you want to get hold or a real person, send an e-mail to jmartinez@kcacademy.org.";
                    // In case any of our lines are larger than 70 characters, we should use wordwrap()
    //                $message = wordwrap($message, 70, "\r\n");
                    // Send
    //                mail('caffeinated@example.com', 'My Subject', $message);
    //                redirect("message_view.php");
    //            }
    //        }
    //    }
        //if the e-mail entered does not match an e-mail on file, apologize
    //    else
    //    {
    //        apologize("You must enter the e-mail address you used to register this account. Try again.");
    //    }
    //
render("forgot_form.php", ["title" => "Forgot"]);
?>