<p>
        <?= "A share of " . $stock["name"] . " (" . $stock["symbol"] . ") costs <strong>$" . $stock["price"] . "</strong>." ?>
</p>




