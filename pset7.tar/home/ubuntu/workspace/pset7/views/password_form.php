<form action="password.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class="form-control" name="password1" placeholder="New Password" type="password"/>
            <input class="form-control" name="password2" placeholder="Password Confirmation" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Reset Password
            </button>
        </div>
    </fieldset>
</form>