<p>Forgot your password, eh?</p>
<p>No worries. You can send a temporary password to your e-mail address.</p>
<form action="forgot.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="email" placeholder="email" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">Send It!</button>
        </div>
    </fieldset>
</form>