<p>A temporary password has been sent to your e-mail address.</p>
<p>If it is not in your in-box, check your junk mail folder.</p>
<p>Be sure to reset your password after logging in with the temporary one.</p>
<p>Click <a href="../public/index.php">here</a> to return to the log-in page.</p>